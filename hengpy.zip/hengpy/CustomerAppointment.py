import UserAppointment

class Customer(UserAppointment.UserAppointment):
    count_id = 1

    def __init__(self, type, doctor, venue, time, date, email, phonenum, name):
        super().__init__(type, doctor, venue, time, date)
        self.__customer_id = Customer.count_id
        self.__email = email
        self.__phonenum = phonenum
        self.__name = name

    def get_customer_id(self):
        return self.__customer_id
    def get_email(self):
        return self.__email
    def get_phonenum(self):
        return self.__phonenum
    def get_name(self):
        return self.__name
    def set_customer_id(self,customer_id):
        self.__customer_id = customer_id
    def set_email(self,email):
        self.__email = email
    def set_phonenum(self, phonenum):
        self.__phonenum = phonenum
    def set_name(self, name):
        self.__name = name

